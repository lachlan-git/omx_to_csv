# omx_to_csv
little website for viewing an omx file

# run instructions
1) install requirements.txt
2) streamlit run main.py --server.port=8888
